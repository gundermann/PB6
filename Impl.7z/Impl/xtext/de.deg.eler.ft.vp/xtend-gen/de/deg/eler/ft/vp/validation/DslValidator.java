package de.deg.eler.ft.vp.validation;

import de.deg.eler.ft.vp.dsl.DslPackage;
import de.deg.eler.ft.vp.dsl.Konfiguration;
import de.deg.eler.ft.vp.validation.AbstractDslValidator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.xbase.lib.Conversions;

/**
 * Custom validation rules.
 * 
 * see http://www.eclipse.org/Xtext/documentation.html#validation
 */
@SuppressWarnings("all")
public class DslValidator extends AbstractDslValidator {
  private String WARNUNG_KEINE_LAUFENDE_NUMMER = "Bei der laufenden Nummer für die Definition der %s wurde bei der Prüfung %s die Nummer %s übersprungen";
  
  private String WARNUNG_KEINE_ID_DEKLARIERT = "Die Prüfung %s wurde nicht deklariert.";
  
  private String WARNUNG_ID_NICHT_VERWENDET = "Die ID %s wird bei der Definition der %s nicht verwendet.";
  
  private String WARUNUNG_DOPPELT_GENUTZTE_PRUEFUNG = "%s ist für die Prüfung %s schon konfiguriert.";
  
  private String WARNUNG_PRUEFUNG_KEINEM_ANTRAG_ZUGEWIESEN = "Die Prüfung %s wurde keinem Antrag zugewiesen.";
  
  @Check
  public void checkIdsFuerAntragszuweisungDeklariert(final Konfiguration konfiguration) {
    EList<String> _spezantragszuweisung = konfiguration.getSpezantragszuweisung();
    EList<String> _usedids = konfiguration.getUsedids();
    String _get = _usedids.get(0);
    this.checkIdsVonZuweisungDeklariert(_spezantragszuweisung, _get, 
      DslPackage.Literals.KONFIGURATION__SPEZANTRAGSZUWEISUNG);
  }
  
  @Check
  public void checkIdsFuerAntragsArtzuweisungDeklariert(final Konfiguration konfiguration) {
    EList<String> _antragszuweisung = konfiguration.getAntragszuweisung();
    EList<String> _usedids = konfiguration.getUsedids();
    String _get = _usedids.get(0);
    this.checkIdsVonZuweisungDeklariert(_antragszuweisung, _get, 
      DslPackage.Literals.KONFIGURATION__ANTRAGSZUWEISUNG);
  }
  
  @Check
  public void checkLaufendeNummerWirkung(final Konfiguration konfiguration) {
    EList<String> _pruefungswirkung = konfiguration.getPruefungswirkung();
    HashMap<String, ArrayList<Integer>> _extrahierePruefungZuLaufendeNummerMapFuerEigenschaft = this.extrahierePruefungZuLaufendeNummerMapFuerEigenschaft(_pruefungswirkung);
    this.checkFehltZahlInLaufenderNummer(_extrahierePruefungZuLaufendeNummerMapFuerEigenschaft, "Wirkung", 
      DslPackage.Literals.KONFIGURATION__PRUEFUNGSWIRKUNG);
  }
  
  @Check
  public void checkLaufendeNummerAktion(final Konfiguration konfiguration) {
    EList<String> _pruefungsaktion = konfiguration.getPruefungsaktion();
    HashMap<String, ArrayList<Integer>> _extrahierePruefungZuLaufendeNummerMapFuerEigenschaft = this.extrahierePruefungZuLaufendeNummerMapFuerEigenschaft(_pruefungsaktion);
    this.checkFehltZahlInLaufenderNummer(_extrahierePruefungZuLaufendeNummerMapFuerEigenschaft, "Aktion", 
      DslPackage.Literals.KONFIGURATION__PRUEFUNGSAKTION);
  }
  
  @Check
  public void checkMehrfacheDefinition(final Konfiguration konfig) {
    EList<String> _usedids = konfig.getUsedids();
    String _get = _usedids.get(0);
    String[] deklariertePruefungen = this.extrahiereDeklariertePruefungen(_get);
    for (final String pruefung : deklariertePruefungen) {
      {
        EList<String> _pruefungskurzbezeichnung = konfig.getPruefungskurzbezeichnung();
        this.checkMehrfacheVerwendungDerPruefung(_pruefungskurzbezeichnung, pruefung, 
          DslPackage.Literals.KONFIGURATION__PRUEFUNGSKURZBEZEICHNUNG);
        EList<String> _pruefungslangtext = konfig.getPruefungslangtext();
        this.checkMehrfacheVerwendungDerPruefung(_pruefungslangtext, pruefung, 
          DslPackage.Literals.KONFIGURATION__PRUEFUNGSLANGTEXT);
        EList<String> _pruefungsichtbarkeit = konfig.getPruefungsichtbarkeit();
        this.checkMehrfacheVerwendungDerPruefung(_pruefungsichtbarkeit, pruefung, 
          DslPackage.Literals.KONFIGURATION__PRUEFUNGSICHTBARKEIT);
      }
    }
  }
  
  @Check
  public void checkIdVerwendung(final Konfiguration konfig) {
    EList<String> _usedids = konfig.getUsedids();
    String _get = _usedids.get(0);
    String[] deklariertePruefungen = this.extrahiereDeklariertePruefungen(_get);
    for (final String pruefung : deklariertePruefungen) {
      EList<String> _antragszuweisung = konfig.getAntragszuweisung();
      EList<String> _spezantragszuweisung = konfig.getSpezantragszuweisung();
      this.checkVerwendungInAntrag(_antragszuweisung, _spezantragszuweisung, pruefung);
    }
  }
  
  public void checkIdsVonZuweisungDeklariert(final EList<String> konfigurationen, final String konfigFuerDeklarierteIDs, final EStructuralFeature feature) {
    int index = 0;
    for (final String konfiguration : konfigurationen) {
      {
        String[] zugewiesenePruefungen = this.extrahiereDeklariertePruefungen(konfiguration);
        for (final String pruefung : zugewiesenePruefungen) {
          {
            String[] deklariertePruefungen = this.extrahiereDeklariertePruefungen(konfigFuerDeklarierteIDs);
            final String[] _converted_deklariertePruefungen = (String[])deklariertePruefungen;
            String _trim = pruefung.trim();
            boolean _contains = ((List<String>)Conversions.doWrapArray(_converted_deklariertePruefungen)).contains(_trim);
            boolean _not = (!_contains);
            if (_not) {
              String _format = String.format(this.WARNUNG_KEINE_ID_DEKLARIERT, pruefung);
              this.error(_format, feature, index);
            }
          }
        }
        index++;
      }
    }
  }
  
  public String[] extrahiereDeklariertePruefungen(final String konfigFuerDeklarierteIDs) {
    int _indexOf = konfigFuerDeklarierteIDs.indexOf("=");
    int _plus = (_indexOf + 1);
    int _length = konfigFuerDeklarierteIDs.length();
    String _substring = konfigFuerDeklarierteIDs.substring(_plus, _length);
    return _substring.split("\\,");
  }
  
  public String extrahierePruefung(final String konfigString) {
    return this.extrahierePart(konfigString, Integer.valueOf(1));
  }
  
  public String extrahierePart(final String konfigString, final Integer part) {
    String[] geteilteKonfig = konfigString.split("\\.");
    String zuExtrahierenderTeil = geteilteKonfig[(part).intValue()];
    boolean _contains = zuExtrahierenderTeil.contains(" ");
    if (_contains) {
      int _indexOf = zuExtrahierenderTeil.indexOf(" ");
      return zuExtrahierenderTeil.substring(0, _indexOf);
    } else {
      return zuExtrahierenderTeil;
    }
  }
  
  public HashMap<String, ArrayList<Integer>> extrahierePruefungZuLaufendeNummerMapFuerEigenschaft(final EList<String> eigenschaften) {
    HashMap<String, ArrayList<Integer>> pruefungZuEigenschaftMap = new HashMap<String, ArrayList<Integer>>();
    for (final String eigenschaft : eigenschaften) {
      {
        String pruefung = this.extrahierePruefung(eigenschaft);
        String laufendeNummer = this.extrahiereLaufendeNummer(eigenschaft);
        ArrayList<Integer> listeMitLaufenderNummer = new ArrayList<Integer>();
        boolean _containsKey = pruefungZuEigenschaftMap.containsKey(pruefung);
        boolean _not = (!_containsKey);
        if (_not) {
        } else {
          ArrayList<Integer> _get = pruefungZuEigenschaftMap.get(pruefung);
          listeMitLaufenderNummer = _get;
        }
        int _parseInt = Integer.parseInt(laufendeNummer);
        listeMitLaufenderNummer.add(Integer.valueOf(_parseInt));
        pruefungZuEigenschaftMap.put(pruefung, listeMitLaufenderNummer);
      }
    }
    return pruefungZuEigenschaftMap;
  }
  
  public String extrahiereLaufendeNummer(final String konfigString) {
    return this.extrahierePart(konfigString, Integer.valueOf(2));
  }
  
  public void checkFehltZahlInLaufenderNummer(final HashMap<String, ArrayList<Integer>> map, final String eigenschaft, final EStructuralFeature feature) {
    int index = 0;
    Set<String> _keySet = map.keySet();
    for (final String pruefung : _keySet) {
      {
        ArrayList<Integer> nummern = map.get(pruefung);
        for (int ln = 1; (ln < nummern.size()); ln++) {
          {
            boolean _contains = nummern.contains(Integer.valueOf(ln));
            boolean _not = (!_contains);
            if (_not) {
              String _format = String.format(this.WARNUNG_KEINE_LAUFENDE_NUMMER, eigenschaft, pruefung, Integer.valueOf(ln));
              this.error(_format, feature, index);
            }
            index++;
          }
        }
      }
    }
  }
  
  public void checkVerwendungInAntrag(final EList<String> zuweisungenZuAntragsart, final EList<String> zuweisungenZuAntrag, final String pruefung) {
    for (final String antragsartZuweisung : zuweisungenZuAntragsart) {
      {
        String[] zugewiesenePreufungen = this.extrahiereDeklariertePruefungen(antragsartZuweisung);
        final String[] _converted_zugewiesenePreufungen = (String[])zugewiesenePreufungen;
        boolean _contains = ((List<String>)Conversions.doWrapArray(_converted_zugewiesenePreufungen)).contains(pruefung);
        if (_contains) {
          return;
        }
      }
    }
    for (final String antragsZuweisung : zuweisungenZuAntrag) {
      {
        String[] zugewiesenePreufungen = this.extrahiereDeklariertePruefungen(antragsZuweisung);
        final String[] _converted_zugewiesenePreufungen = (String[])zugewiesenePreufungen;
        boolean _contains = ((List<String>)Conversions.doWrapArray(_converted_zugewiesenePreufungen)).contains(pruefung);
        if (_contains) {
          return;
        }
      }
    }
    String _format = String.format(this.WARNUNG_PRUEFUNG_KEINEM_ANTRAG_ZUGEWIESEN, pruefung);
    this.error(_format, 
      DslPackage.Literals.KONFIGURATION__USEDIDS);
  }
  
  public void checkMehrfacheVerwendungDerPruefung(final EList<String> list, final String pruefung, final EAttribute attribute) {
    int index = 0;
    int gefundeneKonfigurationen = 0;
    for (final String konfiguration : list) {
      {
        String pruefungBenutzt = this.extrahierePruefung(konfiguration);
        boolean _equals = pruefungBenutzt.equals(pruefung);
        if (_equals) {
          if ((gefundeneKonfigurationen == 0)) {
            gefundeneKonfigurationen = 1;
          } else {
            String _name = attribute.getName();
            String _format = String.format(this.WARUNUNG_DOPPELT_GENUTZTE_PRUEFUNG, _name, pruefung);
            this.error(_format, attribute, index);
          }
        }
        index++;
      }
    }
  }
}
